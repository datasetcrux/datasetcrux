# datasetcrux

Documentation will be added over here.

0.0.1
blank

0.0.2
```
random_string(length)
```

can return random string

0.0.3
OS classifiers added

0.0.31
python minimum 3.6

0.0.32
csv_printer, csv_reader, csv_reader_dict
csv_writer, csv_writer_append, csv_writer_append_dict, csv_writer_append_dict_header, csv_writer_append_dict_header_if_not_exist
csv functions  added
